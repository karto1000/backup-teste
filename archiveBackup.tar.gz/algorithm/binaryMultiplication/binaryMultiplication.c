#include <stdio.h>
#include <stdlib.h>

void printMatrix(int* matrix, int matrixOrder);

int main (int argc, char *argv[]) {
	
	if (argc < 2) {
		printf("Wrong argument. Expected: 'int matrixOrder' int(1) int(2)... int(matrixOrder²-1) int(matrixOrder²)\n");
		return 1;
	}
	
	// To do: limitade error in case of more elements than expected
	/*else if (argc > (((atoi(argv[2]))*(atoi(argv[2])))+2) ) {
		printf("Too many arguments\n");
		return 1;
	}*/

	int matrixOrder = atoi(argv[1]);
	int index = 2;

	int matrix [matrixOrder][matrixOrder];

	for (int i=0; i<matrixOrder; i++) {
		for (int j = 0; j<matrixOrder;j++){
			matrix[i][j] = atoi(argv[index]);
			index++;
		}
	} 

	for (int i=0; i<matrixOrder; i++) {
		for (int j = 0; j<matrixOrder;j++){
			printf(" %d", matrix[i][j]);			
		}
		printf("\n");
	} 
	
	printf("\n");

	printMatrix(*matrix, matrixOrder);

	return 0;
}


void printMatrix(int* matrix, int matrixOrder) {
		
	for (int i=0; i<matrixOrder; i++) {
		for (int j = 0; j<matrixOrder;j++){
			printf(" %d", *(matrix+i+j));			
		}
		printf("\n");
	} 	
}

void binaryMultiplication (int* matrix, int matrixOrder) {
		

}

